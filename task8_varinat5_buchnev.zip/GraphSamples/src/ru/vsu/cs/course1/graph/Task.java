package ru.vsu.cs.course1.graph;

import com.kitfox.svg.A;
import ru.vsu.cs.course1.graph.demo.FrameMain;

import java.awt.*;
import java.awt.geom.Path2D;
import java.util.*;
import java.util.List;

public class Task {

    public static void taskMain(String[] args){
        Locale.setDefault(Locale.ROOT);
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrameMain().setVisible(true);
            }
        });
    }
    public static List<List<Integer>> parseText(String text,ListsGraph graph){
        List<List<Integer>> list = new ArrayList<>();
        String[] a = text.split("\n");
        for (int i = 0; i < a.length; i++) {
            List<Integer> listCurr = new ArrayList<>();
            String[] b = a[i].split(" ");
            int x = Integer.parseInt(b[0]);
            int y = Integer.parseInt(b[1]);
            listCurr.add(x);
            listCurr.add(y);
            graph.addXY(x,y);
            list.add(listCurr);
        }

    return list;
    }
    public static void printVertex(Graphics2D g2d, int windth, int height, List<List<Integer>> list){
        //g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        //Color color = g2d.getColor();
        g2d.setColor(Color.YELLOW);
        for(int i = 0 ; i < list.size();i++){
            g2d.setColor(Color.YELLOW);
            int x = list.get(i).get(0);
            int y = list.get(i).get(1);
            g2d.fillOval(x,y,30, 30);
            g2d.setColor(Color.BLACK);
            g2d.drawString(String.valueOf(i),x + (30/2)-2,y + (30/2)+2);

        }

    }
    public static void parseSv(String text, AdjListsGraph graph){
        String[] a = text.split("\n");
        for (int i = 0; i < a.length; i++) {
            List<Integer> listCurr = new ArrayList<>();
            String[] b = a[i].split(" ");
            int v1 = Integer.parseInt(b[0]);
            int v2 = Integer.parseInt(b[1]);
            graph.addAdge(v1,v2);
        }

    }
    public static void printAdge(Graphics2D g2d,AdjListsGraph graph , List<List<Integer>> a){
        for (int i = 0; i < graph.vertexCount(); i++) {
            int x0 = a.get(i).get(0);
            int y0 = a.get(i).get(1);
            for (Integer item : graph.adjacencies(i)) {
                int x1 = a.get(item).get(0);
                int y1 = a.get(item).get(1);
                g2d.drawLine(x0 + 30 / 2, y0 + 30 / 2, x1 + 30 / 2, y1 + 30 / 2);
                //System.out.println(item);
            }
        }
    }
    public static double angle(double[] a,double[] b){
        double TAU = Math.PI * 2;
        double angle = Math.atan2(a[0] * b[1] - a[1] * b[0], a[0] * b[0] + a[1] * b[1]);
        if (angle < 0) {
            angle += TAU;
        }
        return angle;
    }
    public static double[] getVect(int one, int two ,ListsGraph graph){
        List<Integer> a = graph.getCoods().get(one);
        List<Integer> b = graph.getCoods().get(two);
        double[] result = new double[2];
        int x1 = a.get(0) - 15;
        int y1 = a.get(1) - 15;
        int x2 = b.get(0) - 15;
        int y2 = b.get(1) - 15;
        result[0] = x2 - x1;
        result[1] = y2 - y1;
        return result;
    }
    public static int[] parseC(String text){
        int[] res = new int[2];
        String[] a = text.split(" ");
        res[0] = Integer.parseInt(a[0]);
        res[1] = Integer.parseInt(a[1]);
        return res;
    }
    public static double angleBetweenVect(int a,int b,int c,ListsGraph graph){
        double result;
        if (180 - angle(getVect(a,b,graph),getVect(b,c,graph)) * (180/Math.PI) < 0 ){
            return 360 - Math.abs(180 - angle(getVect(a,b,graph),getVect(b,c,graph)) * (180/Math.PI));
        }
        return 180 - angle(getVect(a,b,graph),getVect(b,c,graph)) * (180/Math.PI);
    }
    public static List<Integer> wayGraph(int a,int b,String text,ListsGraph graph){
        String[] arr = text.split("");
        List<Integer> list = new ArrayList<>();
        list.add(a);
        list.add(b);
        for(int i = 1; i <= arr.length; i++){
            List<Integer> listcurr = new ArrayList<>();
            int v = list.get(i);
            int prev = list.get(i-1);
            //System.out.println("v - " + v);
            //System.out.println("prev - " + prev);
            for (Integer item:graph.adjacencies(v)){
                if(item != prev){
                    //System.out.println("item - " + item);
                    listcurr.add(item);
                }
            }
            //System.out.println(listcurr);
           //System.out.println("vect - " + prev + " " + v + " " + listcurr.get(0) + " --- " + angleBetweenVect(prev,v,listcurr.get(0),graph));
            //System.out.println("vect - " + prev + " " + v + " " + listcurr.get(1) + " --- " + angleBetweenVect(prev,v,listcurr.get(1),graph));
            if (angleBetweenVect(prev,v,listcurr.get(0),graph)  < angleBetweenVect(prev,v,listcurr.get(1),graph) ){
                if(arr[i-1].equals("L")){
                    list.add(listcurr.get(1));
                }
                else  if(arr[i-1].equals("R")){
                    list.add(listcurr.get(0));
                }
            }
            else if(angleBetweenVect(prev,v,listcurr.get(0),graph) > angleBetweenVect(prev,v,listcurr.get(1),graph)){
                if(arr[i-1].equals("L")){
                    list.add(listcurr.get(0));
                }
                else  if(arr[i-1].equals("R")){
                    list.add(listcurr.get(1));
                }
            }
        }
        return list;
    }
    public static String listToString(List<Integer> list){
        String res = "";
        for (int i = 0; i < list.size(); i++) {
            res +=list.get(i)+" ";
        }
        return res;
    }
    public static Result search(Graph graph, int path, int target, int from, boolean[] visited,String str){
        Result result = new Result();
        visited[from] = true;
        result.min = 5555555;
        for (Integer v : graph.adjacencies(from)) {
            if (!visited[v]) {
                if (graph.isAdj(from, v)) {
                    if (v == target) {
                        result.min = path + 1;
                        result.str = str + String.valueOf(from);
                        return result;
                    } else {
                        Result a = search(graph, path + 1, target, v, visited,str);
                        if (a.min < result.min) {
                            result.min = a.min;
                            result.str = a.str + from;
                        }
                    }
                }
            }
        }
        return result;
    }
    public static class Result{
        public int min;
        public String str;
    }
    public static String swapStr(String str){
        String result = "";
        String[] a = str.split("");
        for (int i = a.length-1;i>0;i--){
            result += a[i] + " ";
        }
        return result;
    }

}
