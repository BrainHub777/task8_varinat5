package ru.vsu.cs.course1.graph;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class ListsGraph extends AdjListsGraph {
    private List<List<Integer>> coords = new ArrayList<>();
    public void addXY(int x, int y){
        List<Integer> listCurr = new ArrayList<>();
        listCurr.add(x);
        listCurr.add(y);
        vEdjLists.add(new LinkedList<>());
        vCount++;
        coords.add(listCurr);
    }
    public void removeVertex(int index){
        coords.remove(index);
        deleteVertex(index);
    }
    public List<List<Integer>> getCoods(){
        return coords;
    }
    public void clearCoords(){
        coords = new ArrayList<>();
    }
    public void deleteVertex(int v) {
        if (v < vCount) {
            for (Integer vertex : vEdjLists.get(v)) { //заходим в списко вершин удаляемого элемента
                vEdjLists.get(vertex).remove((Integer) v);  //удаляем связь с удаляемой вершиной в этих списках
            }
            vEdjLists.remove(v);
            vCount--;
            for (List<Integer> v1 :
                    vEdjLists) {
                for (Integer v2 :
                        v1) {
                    if (v2 > v) {
                        v1.set(v1.indexOf(v2), v2 - 1);
                    }
                }
            }
        }
    }
    public void graphClear(){
        coords = new ArrayList<>();
        vEdjLists = new ArrayList<>();
        vCount = 0;
        eCount = 0;
    }
}
