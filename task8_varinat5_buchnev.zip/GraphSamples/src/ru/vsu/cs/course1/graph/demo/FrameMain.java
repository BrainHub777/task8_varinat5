package ru.vsu.cs.course1.graph.demo;

import com.intellij.uiDesigner.core.GridConstraints;
import com.intellij.uiDesigner.core.GridLayoutManager;
import com.intellij.uiDesigner.core.Spacer;
import ru.vsu.cs.course1.graph.ListsGraph;
import ru.vsu.cs.course1.graph.Task;
import ru.vsu.cs.util.SwingUtils;

import javax.swing.*;
import javax.xml.transform.Result;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FrameMain extends JFrame {
    private JPanel panelMain;
    private JTextArea textArea1;
    private JPanel imgJPanel;
    private JButton button1;
    private JLabel lableImg;
    private JTextArea textArea2;
    private JCheckBox checkDelete;
    private JCheckBox chekAddVertex;
    private JTextArea textArea3;
    private JButton button2;
    private JButton buttonDelete;
    private JButton buttonWay;
    private JTextArea textArea4;
    private JButton найтиMinПутьButton;
    private JTextArea textArea5;
    private JCheckBox checkAdd;

    public FrameMain() {
        $$$setupUI$$$();
        this.setTitle("Графы.Собственная реализация!");
        this.setContentPane(panelMain);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.pack();
        //imgJPanel.setLayout(null);
        ListsGraph graph = new ListsGraph();
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /*for (int i = 0; i < graph.getCoods().size(); i++) {
                    graph.removeVertex(i);
                }
                 */
                //graph.clearCoords();
                graph.graphClear();
                List<List<Integer>> a = Task.parseText(textArea1.getText(), graph);
                Task.parseSv(textArea2.getText(), graph);
                BufferedImage img = new BufferedImage(1000, 900, BufferedImage.TYPE_INT_BGR);
                Graphics2D g2d = img.createGraphics();
                g2d.setColor(Color.WHITE);
                g2d.fillRect(0, 0, 1000, 900);
                g2d.setColor(Color.BLACK);
                Task.printAdge(g2d, graph, graph.getCoods());
                Task.printVertex(g2d, 1000, 900, graph.getCoods());
                //for (int i = 0; i < graph.getCoods().size(); i++) {
                //    System.out.println(graph.getCoods().get(i));
                //}
                //System.out.println("467 - " + (Task.angleBetweenVect(Task.getVect(4, 6, graph), Task.getVect(6, 7, graph)) * (180 / Math.PI)));
                //System.out.println("462 - " + (Task.angleBetweenVect(Task.getVect(4, 6, graph), Task.getVect(6, 2, graph)) * (180 / Math.PI)));
                lableImg.setIcon(new ImageIcon(img));
            }
        });




        imgJPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent evt) {
                if (evt.getButton() == MouseEvent.BUTTON1 && evt.getX() < imgJPanel.getWidth() && evt.getY() < imgJPanel.getHeight() && checkDelete.isSelected()) {
                    for (int i = 0; i < graph.getCoods().size(); i++) {
                        if (evt.getX() <= graph.getCoods().get(i).get(0) + 30 && evt.getX() >= graph.getCoods().get(i).get(0) && evt.getY() <= graph.getCoods().get(i).get(1) + 30 && evt.getY() >= graph.getCoods().get(i).get(1)) {
                            graph.removeVertex(i);
                            //System.out.println(graph.getCoods());
                            BufferedImage img = new BufferedImage(1000, 900, BufferedImage.TYPE_INT_BGR);
                            Graphics2D g2d = img.createGraphics();
                            g2d.setColor(Color.WHITE);
                            g2d.fillRect(0, 0, 1000, 900);
                            g2d.setColor(Color.BLACK);
                            Task.printAdge(g2d, graph, graph.getCoods());
                            Task.printVertex(g2d, 1000, 900, graph.getCoods());
                            lableImg.setIcon(new ImageIcon(img));
                        }
                    }
                }
                if (evt.getButton() == MouseEvent.BUTTON1 && evt.getX() < imgJPanel.getWidth() && evt.getY() < imgJPanel.getHeight() && chekAddVertex.isSelected()) {
                    int x = evt.getX() - 30 / 2;
                    int y = evt.getY() - 30 / 2;
                    graph.addXY(x, y);
                    BufferedImage img = new BufferedImage(1000, 900, BufferedImage.TYPE_INT_BGR);
                    Graphics2D g2d = img.createGraphics();
                    g2d.setColor(Color.WHITE);
                    g2d.fillRect(0, 0, 1000, 900);
                    g2d.setColor(Color.BLACK);
                    Task.printAdge(g2d, graph, graph.getCoods());
                    Task.printVertex(g2d, 1000, 900, graph.getCoods());
                    lableImg.setIcon(new ImageIcon(img));
                }
            }
        });

        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int[] coord = Task.parseC(textArea3.getText());
                graph.addAdge(coord[0], coord[1]);
                BufferedImage img = new BufferedImage(1000, 900, BufferedImage.TYPE_INT_BGR);
                Graphics2D g2d = img.createGraphics();
                g2d.setColor(Color.WHITE);
                g2d.fillRect(0, 0, 1000, 900);
                g2d.setColor(Color.BLACK);
                Task.printAdge(g2d, graph, graph.getCoods());
                Task.printVertex(g2d, 1000, 900, graph.getCoods());
                lableImg.setIcon(new ImageIcon(img));
            }
        });
        buttonWay.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int[] vertex = Task.parseC(textArea4.getText());
                List<Integer> way = Task.wayGraph(vertex[0], vertex[1], "LRRLLR", graph);
                SwingUtils.showInfoMessageBox("Путь " + Task.listToString(way));
                BufferedImage img = new BufferedImage(1000, 900, BufferedImage.TYPE_INT_BGR);
                Graphics2D g2d = img.createGraphics();
                g2d.setColor(Color.WHITE);
                g2d.fillRect(0, 0, 1000, 900);
                g2d.setColor(Color.BLACK);
                Task.printAdge(g2d, graph, graph.getCoods());
                Task.printVertex(g2d, 1000, 900, graph.getCoods());
                g2d.setColor(Color.GREEN);
                for (int i = 0; i < way.size() - 1; i++) {
                    int x0 = graph.getCoods().get(way.get(i)).get(0);
                    int y0 = graph.getCoods().get(way.get(i)).get(1);
                    int x1 = graph.getCoods().get(way.get(i + 1)).get(0);
                    int y1 = graph.getCoods().get(way.get(i + 1)).get(1);
                    g2d.drawLine(x0 + 30 / 2, y0 + 30 / 2, x1 + 30 / 2, y1 + 30 / 2);
                }
                lableImg.setIcon(new ImageIcon(img));
                //System.out.println(Task.wayGraph(1, 5, "LRRLLR", graph));
            }
        });
        buttonDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int[] coord = Task.parseC(textArea3.getText());
                graph.removeAdge(coord[0], coord[1]);
                BufferedImage img = new BufferedImage(1000, 900, BufferedImage.TYPE_INT_BGR);
                Graphics2D g2d = img.createGraphics();
                g2d.setColor(Color.WHITE);
                g2d.fillRect(0, 0, 1000, 900);
                g2d.setColor(Color.BLACK);
                Task.printAdge(g2d, graph, graph.getCoods());
                Task.printVertex(g2d, 1000, 900, graph.getCoods());
                lableImg.setIcon(new ImageIcon(img));
            }
        });
        найтиMinПутьButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int[] vertex = Task.parseC(textArea5.getText());
                boolean[] visited = new boolean[graph.vertexCount()];
                String str = "" + vertex[1];
                String a = Task.search(graph, 0, vertex[1], vertex[0], visited, str).str;
                str += a;
                String v = Task.swapStr(str);
                String[] arr = v.split(" ");
                List<Integer> way = new ArrayList<>();
                for (int i = 0; i < a.length(); i++) {
                    way.add(Integer.parseInt(arr[i]));
                }
                SwingUtils.showInfoMessageBox("Путь " + v);
                BufferedImage img = new BufferedImage(1000, 900, BufferedImage.TYPE_INT_BGR);
                Graphics2D g2d = img.createGraphics();
                g2d.setColor(Color.WHITE);
                g2d.fillRect(0, 0, 1000, 900);
                g2d.setColor(Color.BLACK);
                Task.printAdge(g2d, graph, graph.getCoods());
                Task.printVertex(g2d, 1000, 900, graph.getCoods());
                g2d.setColor(Color.GREEN);
                for (int i = 0; i < way.size() - 1; i++) {
                    int x0 = graph.getCoods().get(way.get(i)).get(0);
                    int y0 = graph.getCoods().get(way.get(i)).get(1);
                    int x1 = graph.getCoods().get(way.get(i + 1)).get(0);
                    int y1 = graph.getCoods().get(way.get(i + 1)).get(1);
                    g2d.drawLine(x0 + 30 / 2, y0 + 30 / 2, x1 + 30 / 2, y1 + 30 / 2);
                }
                lableImg.setIcon(new ImageIcon(img));

            }
        });
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        panelMain = new JPanel();
        panelMain.setLayout(new GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1));
        final JPanel panel1 = new JPanel();
        panel1.setLayout(new GridLayoutManager(2, 2, new Insets(0, 0, 0, 0), -1, -1));
        panelMain.add(panel1, new GridConstraints(0, 0, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, null, new Dimension(500, 500), null, 0, false));
        imgJPanel = new JPanel();
        imgJPanel.setLayout(new GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1));
        panel1.add(imgJPanel, new GridConstraints(0, 0, 1, 1, GridConstraints.ANCHOR_NORTHWEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, null, new Dimension(500, 500), null, 0, false));
        lableImg = new JLabel();
        lableImg.setText("");
        imgJPanel.add(lableImg, new GridConstraints(0, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JPanel panel2 = new JPanel();
        panel2.setLayout(new GridLayoutManager(12, 4, new Insets(0, 0, 0, 0), -1, -1));
        panel1.add(panel2, new GridConstraints(0, 1, 2, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        final Spacer spacer1 = new Spacer();
        panel2.add(spacer1, new GridConstraints(11, 3, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_VERTICAL, 1, GridConstraints.SIZEPOLICY_WANT_GROW, null, null, null, 0, false));
        final JScrollPane scrollPane1 = new JScrollPane();
        panel2.add(scrollPane1, new GridConstraints(1, 1, 1, 3, GridConstraints.ANCHOR_EAST, GridConstraints.FILL_VERTICAL, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(100, 500), null, 0, false));
        textArea1 = new JTextArea();
        scrollPane1.setViewportView(textArea1);
        final JLabel label1 = new JLabel();
        label1.setText("Координаты:");
        panel2.add(label1, new GridConstraints(0, 1, 1, 3, GridConstraints.ANCHOR_EAST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JLabel label2 = new JLabel();
        label2.setText("Связи:");
        panel2.add(label2, new GridConstraints(2, 1, 1, 3, GridConstraints.ANCHOR_EAST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JScrollPane scrollPane2 = new JScrollPane();
        panel2.add(scrollPane2, new GridConstraints(3, 1, 1, 3, GridConstraints.ANCHOR_EAST, GridConstraints.FILL_VERTICAL, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(100, 150), null, 0, false));
        textArea2 = new JTextArea();
        scrollPane2.setViewportView(textArea2);
        checkDelete = new JCheckBox();
        checkDelete.setText("Активировать удаление");
        panel2.add(checkDelete, new GridConstraints(4, 1, 1, 3, GridConstraints.ANCHOR_EAST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        chekAddVertex = new JCheckBox();
        chekAddVertex.setText("Активировать добавление");
        panel2.add(chekAddVertex, new GridConstraints(5, 1, 1, 3, GridConstraints.ANCHOR_EAST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        textArea3 = new JTextArea();
        panel2.add(textArea3, new GridConstraints(6, 3, 1, 1, GridConstraints.ANCHOR_EAST, GridConstraints.FILL_VERTICAL, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(100, 25), null, 0, false));
        button2 = new JButton();
        button2.setText("Добавить");
        panel2.add(button2, new GridConstraints(7, 2, 1, 2, GridConstraints.ANCHOR_EAST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JLabel label3 = new JLabel();
        label3.setText("Введите ребро");
        panel2.add(label3, new GridConstraints(6, 1, 1, 2, GridConstraints.ANCHOR_EAST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        button1 = new JButton();
        button1.setText("Построить граф");
        panel2.add(button1, new GridConstraints(8, 1, 1, 3, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final Spacer spacer2 = new Spacer();
        panel2.add(spacer2, new GridConstraints(6, 0, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_WANT_GROW, 1, null, null, null, 0, false));
        buttonDelete = new JButton();
        buttonDelete.setText("Удалить");
        panel2.add(buttonDelete, new GridConstraints(7, 1, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        buttonWay = new JButton();
        buttonWay.setText("Найти путь");
        panel2.add(buttonWay, new GridConstraints(9, 1, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        textArea4 = new JTextArea();
        panel2.add(textArea4, new GridConstraints(9, 3, 1, 1, GridConstraints.ANCHOR_EAST, GridConstraints.FILL_VERTICAL, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(100, 25), null, 0, false));
        найтиMinПутьButton = new JButton();
        найтиMinПутьButton.setText("Найти min путь");
        panel2.add(найтиMinПутьButton, new GridConstraints(10, 1, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        textArea5 = new JTextArea();
        panel2.add(textArea5, new GridConstraints(10, 3, 1, 1, GridConstraints.ANCHOR_EAST, GridConstraints.FILL_VERTICAL, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(100, 25), null, 0, false));
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return panelMain;
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }


}
